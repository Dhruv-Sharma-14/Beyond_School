import Foundation
import simd

#if canImport(RealityKit)
import RealityKit
#endif

@MainActor
public final class TrafficCorridorController {
    public struct Vehicle: Sendable, Equatable {
        public let identifier: String
        public var x: Float
        public let speed: Float

        public init(identifier: String, x: Float, speed: Float) {
            self.identifier = identifier
            self.x = x
            self.speed = speed
        }
    }

    public let laneY: Float = -3.6
    public let dangerZone: ClosedRange<Float> = -18...4
    public private(set) var vehicles: [Vehicle] = [
        Vehicle(identifier: "TrafficVehicle_00", x: -24, speed: 7.0),
        Vehicle(identifier: "TrafficVehicle_01", x: -10, speed: 8.5)
    ]

    public init() {}

    public var isDangerZoneOccupied: Bool {
        vehicles.contains { dangerZone.contains($0.x) }
    }

    public func update(deltaTime: Float) {
        guard deltaTime > 0 else { return }
        for index in vehicles.indices {
            vehicles[index].x += vehicles[index].speed * deltaTime
            if vehicles[index].x > 24 {
                vehicles[index].x = -24
            }
        }
    }

    public func resetForSmokeTest(positions: [Float]) {
        for (index, position) in positions.prefix(vehicles.count).enumerated() {
            vehicles[index].x = position
        }
    }

    #if canImport(RealityKit)
    public func install(in root: Entity, audio: SpatialAudioEngine) {
        for vehicle in vehicles {
            let entity = makeVehicleEntity(identifier: vehicle.identifier)
            entity.position = [vehicle.x, laneY, 0.55]
            root.addChild(entity)
            audio.attach(.trafficWhoosh, to: entity, name: vehicle.identifier)
        }
    }

    public func synchronize(in root: Entity, deltaTime: Float) {
        update(deltaTime: deltaTime)
        for vehicle in vehicles {
            guard let entity = root.findTrafficEntity(named: vehicle.identifier) else { continue }
            entity.position.x = vehicle.x
        }
    }

    private func makeVehicleEntity(identifier: String) -> Entity {
        let root = Entity()
        root.name = identifier
        let body = ModelEntity(
            mesh: .generateBox(size: [1.5, 0.75, 0.45]),
            materials: [SimpleMaterial(color: .darkGray, isMetallic: true)]
        )
        body.name = "\(identifier)_Body"
        root.addChild(body)

        let lampMaterial = UnlitMaterial(color: .white)
        let headlamp = ModelEntity(
            mesh: .generateBox(size: [0.12, 0.22, 0.08]),
            materials: [lampMaterial]
        )
        headlamp.name = "\(identifier)_Headlamps"
        headlamp.position = [0.72, -0.22, 0.05]
        root.addChild(headlamp)

        let tailMaterial = UnlitMaterial(color: .red)
        let taillamp = ModelEntity(
            mesh: .generateBox(size: [0.12, 0.22, 0.08]),
            materials: [tailMaterial]
        )
        taillamp.name = "\(identifier)_Taillamps"
        taillamp.position = [-0.72, 0.22, 0.05]
        root.addChild(taillamp)

        return root
    }
    #endif
}

#if canImport(RealityKit)
private extension Entity {
    func findTrafficEntity(named name: String) -> Entity? {
        if self.name == name { return self }
        for child in children {
            if let match = child.findTrafficEntity(named: name) { return match }
        }
        return nil
    }
}
#endif
